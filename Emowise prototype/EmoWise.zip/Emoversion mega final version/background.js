const GEMINI_API_KEY = "AIzaSyDozHcEqAtVQMCTCETL15bgzZvnrkBoN9Y";

const AVAILABLE_MODELS = [
  'gemini-1.5-pro-002',
  'gemini-1.5-pro',
  'gemini-1.5-flash'
];

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "getGeminiSuggestion") {
    getGeminiSuggestionWithFallback(request.conversationHistory, request.tone)
      .then(suggestions => {
        sendResponse({ suggestions: suggestions });
      })
      .catch(error => {
        console.error('Error:', error);
        sendResponse({ error: error.message || 'Failed to generate suggestions' });
      });
    return true;
  }
});

async function getGeminiSuggestionWithFallback(conversationHistory, tone) {
  let lastError = null;
  for (const model of AVAILABLE_MODELS) {
    try {
      const suggestions = await getGeminiSuggestion(conversationHistory, tone, model);
      return suggestions;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError || new Error("All models failed");
}

async function getGeminiSuggestion(conversationHistory, tone, model) {
  const historyText = conversationHistory.join('\n');
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${GEMINI_API_KEY}`;
  const prompt = `You are EmoWise, an AI assistant for Instagram DMs. Here is the recent conversation:\n\n${historyText}\n\nBased on this, generate 12-15 creative, concise, and context-aware reply suggestions to the last message in a "${tone}" tone. 

Important guidelines:
1. Use diverse, relevant emojis appropriately
2. If the conversation appears to be in Hinglish, respond in Hinglish
3. Make responses sound natural
4. Vary the length and style of suggestions
5. Consider the context and relationship
6. Avoid clichés and generic responses
7. Match the energy level of the conversation
8. Do not add quotes in the start and end

Only return the suggestions as a numbered list.`;

  const body = {
    contents: [{ parts: [{ text: prompt }] }]
  };

  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });

  if (!response.ok) throw new Error("API error");

  const data = await response.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || "";
  const suggestions = text
    .split(/\n+/)
    .map(line => line.replace(/^\d+\.\s*/, '').trim())
    .filter(Boolean);

  return suggestions.slice(0, 15);
}